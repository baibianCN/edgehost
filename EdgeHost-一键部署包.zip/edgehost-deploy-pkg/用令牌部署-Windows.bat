@echo off
chcp 65001 >nul
title EdgeHost 令牌部署
cd /d "%~dp0"

echo.
echo  ============================================================
echo    EdgeHost - 用 API 令牌部署（最稳定的方式）
echo  ============================================================
echo.
echo  令牌在哪拿？打开这个地址：
echo  https://dash.cloudflare.com/profile/api-tokens
echo  点 Create Token - Edit Cloudflare Workers 模板 - Use template
echo  一路 Next - Create，复制那串令牌。
echo.

where node >nul 2>nul
if %errorlevel% neq 0 (
    echo  [!] 没检测到 Node.js，正在打开官网。装好后重新双击。
    start https://nodejs.org/
    pause
    exit /b 1
)

set /p "TOKEN=请把令牌粘贴到这里，然后按回车: "

echo.
echo  [1/2] 正在安装依赖（第一次几分钟）...
call npm install --no-audit --no-fund
if %errorlevel% neq 0 (
    echo  [X] 依赖安装失败，检查网络后重试。
    pause
    exit /b 1
)

echo  [2/2] 正在用令牌部署...
set CLOUDFLARE_API_TOKEN=%TOKEN%
call npx wrangler deploy
if %errorlevel% neq 0 (
    echo.
    echo  [X] 部署失败。把红色报错截图发给作者。
    pause
    exit /b 1
)

echo.
echo  ============================================================
echo    部署成功！！！
echo    上面 https://xxx.workers.dev 就是你的网站。
echo    网址后面加 /__admin 进管理面板，首次进去设密码。
echo  ============================================================
echo.
pause
