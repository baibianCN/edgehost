@echo off
chcp 65001 >nul
title EdgeHost 一键部署
cd /d "%~dp0"

echo.
echo  ============================================================
echo    EdgeHost - PHP 虚拟主机 一键部署
echo  ============================================================
echo.
echo  这个脚本会：安装依赖 - 打开浏览器登录 Cloudflare - 自动部署
echo  全程你只需要：点「允许」，以及在浏览器里登录一次 Cloudflare
echo.

REM ---------- 第 0 步：检查 Node.js ----------
where node >nul 2>nul
if %errorlevel% neq 0 (
    echo  [!] 你的电脑还没装 Node.js，正在打开官网下载页...
    echo      下载 LTS 版本（长期支持版），一路点「下一步」装完即可。
    echo      装完以后，重新双击本文件。
    echo.
    start https://nodejs.org/
    pause
    exit /b 1
)

echo  [OK] 检测到 Node.js：
node -v
echo.

REM ---------- 第 1 步：安装依赖 ----------
echo  ------------------------------------------------------------
echo  [1/3] 正在安装依赖（第一次要几分钟，请耐心等，别关窗口）...
echo  ------------------------------------------------------------
call npm install --no-audit --no-fund
if %errorlevel% neq 0 (
    echo  [X] 依赖安装失败。多半是网络问题，请连好网后重新双击。
    pause
    exit /b 1
)
echo  [OK] 依赖装好了。
echo.

REM ---------- 第 2 步：登录 Cloudflare ----------
echo  ------------------------------------------------------------
echo  [2/3] 接下来浏览器会自动打开 Cloudflare 登录页。
echo        请登录你的 Cloudflare 账号并点「允许 / Authorize」。
echo        登录成功后回到这个窗口，脚本会自动继续。
echo  ------------------------------------------------------------
pause
call npx wrangler login
echo.

REM ---------- 第 3 步：部署 ----------
echo  ------------------------------------------------------------
echo  [3/3] 正在部署到 Cloudflare，请稍候...
echo  ------------------------------------------------------------
call npx wrangler deploy
if %errorlevel% neq 0 (
    echo.
    echo  [X] 部署失败。请把这个窗口里的红色报错截图发给作者。
    pause
    exit /b 1
)

echo.
echo  ============================================================
echo    部署成功！！！
echo.
echo    上面那个 https://xxx.workers.dev 就是你的网站地址。
echo    在地址后面加上 /__admin 就是管理面板，
echo    第一次打开会在网页里让你设置管理员密码。
echo  ============================================================
echo.
pause
