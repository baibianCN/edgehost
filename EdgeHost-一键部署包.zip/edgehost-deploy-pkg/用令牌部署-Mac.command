#!/bin/bash
cd "$(dirname "$0")"

echo ""
echo "  ============================================================"
echo "    EdgeHost - 用 API 令牌部署（最稳定的方式）"
echo "  ============================================================"
echo ""
echo "  令牌在哪拿？打开这个地址："
echo "  https://dash.cloudflare.com/profile/api-tokens"
echo "  点 Create Token - Edit Cloudflare Workers 模板 - Use template"
echo "  一路 Next - Create，复制那串令牌。"
echo ""

if ! command -v node >/dev/null 2>&1; then
    echo "  [!] 没检测到 Node.js，正在打开官网。装好后重新双击。"
    open "https://nodejs.org/"
    read -p "按回车退出..."
    exit 1
fi

read -p "  请把令牌粘贴到这里，然后按回车: " TOKEN

echo ""
echo "  [1/2] 正在安装依赖（第一次几分钟）..."
npm install --no-audit --no-fund
if [ $? -ne 0 ]; then
    echo "  [X] 依赖安装失败，检查网络后重试。"
    read -p "按回车退出..."
    exit 1
fi

echo "  [2/2] 正在用令牌部署..."
export CLOUDFLARE_API_TOKEN="$TOKEN"
npx wrangler deploy
if [ $? -ne 0 ]; then
    echo ""
    echo "  [X] 部署失败。把红色报错截图发给作者。"
    read -p "按回车退出..."
    exit 1
fi

echo ""
echo "  ============================================================"
echo "    部署成功！！！"
echo "    上面 https://xxx.workers.dev 就是你的网站。"
echo "    网址后面加 /__admin 进管理面板，首次进去设密码。"
echo "  ============================================================"
echo ""
read -p "按回车退出..."
